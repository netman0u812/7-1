# FPMS — Firewall Policy Management System
## Comprehensive Project Context Prompt

---

## What this project is

We are building the **Firewall Policy Management System (FPMS)** for CVS Health / Aetna Network Security Engineering. This is a four-part standalone HTML tool that replaces the current IP-based firewall rule request process with an object-driven, intelligence-enriched, policy-first system.

The system runs as **standalone HTML files** — no server, no build step, no dependencies. Engineers open the file in a browser.

---

## Core design principles

**The two-question framework:** Every firewall request reduces to exactly two questions:
1. What resource does my application need to access? (resource definition + validation)
2. Should my application be permitted to access that resource? (policy decision + rule generation)

**The zone is a policy abstraction.** It does not exist on the firewall as a concept the firewall invented. The zone is derived from the source/destination object category and used to drive NAT type, security profile group, and decrypt policy. Engineers never select zones — they are conclusions.

**Object-first.** No raw IPs in rule requests. Everything must be a named catalog object (NG-* network group or SO-* address object from the CCD platform).

**The six-category model** drives zone derivation:
- Internal-Net → zone: trust (NG-CORP-*, NG-DATACENTER-*, NG-CAREPLUS-*, NG-OMNICARE-*, etc.)
- Internal-Object → zone: trust (APP_*, SVC_*, AO-CORP-*, AO-DATACENTER-*, etc.)
- Partner-Net → zone: vpn-partner (NG-PARTNER-*)
- Partner-Object → zone: vpn-partner (AO-PARTNER-*)
- External-Net → zone: app-outbound (NG-AWS, NG-AZURE, NG-GCP, NG-CLOUD — NOTE: currently misclassified as Internal-Net, needs fix)
- External-Object → zone: app-outbound (AO-AWS, AO-AZURE, AO-GCP, AO-COLO-*, INTERNET/IPSEC suffix SO-*)

---

## The CCD object catalog

The CCD EDL catalog (ccd_objects_20260617.zip, exported 2026-06-17) is the source of truth for all objects.

**Net_Object (SO-* catalog) — 3,243 objects:**
- Naming: [CLASS]_[APPNAME]_[ENVIRONMENT]
- Classes: APP (2,755), SVC (269), DELIVERY (135), INFRA (78)
- Environments: PBM, HCB, AZ, GCP, COLO, CVS, UNKNOWN, INTERNET, IPSEC, RETAIL, SHEA, WDC, MDC, etc.
- Examples: APP_CRBP_GCP, SVC_AD_AETNA_HCB, INFRA_IBM_ISERIES_WDC

**Net_Group (NG-* + AO-* catalog) — 728 objects:**
- Naming: NG-[SEGMENT]-[LOCATION]-[BU] or AO-[SEGMENT]-[LOCATION]-[BU]
- Segments: CORP, DATACENTER, CAREPLUS, OMNICARE, PARTNER, CALL-CENTER, DISTRIBUTION, CORAM, SPECIALTY, MAIL-ORDER, COLO, VPN, DR, AWS, AZURE, GCP, CLOUD
- Examples: NG-CORP-CT, NG-DATACENTER-WINDSOR-CT-AETNA-WDC, AO-PARTNER-EAST-WINDSOR-NJ-CONDUENT

**IP reverse lookup:** A /16 prefix map (471 buckets) allows engineers to search by IP address and find the containing NG/AO object.

**App name generation:** Script `generate_app_names.py` uses Claude API to generate human-readable names from EDL object names (e.g. APP_CRBP_GCP → "Caremark Rx Benefits Platform (GCP)"). Requires Anthropic API key. Produces `app_name_map.json` for embedding in the tool. **Not yet run — needs API key.**

---

## Ten traffic flow patterns

Every rule request maps to one of ten canonical patterns, auto-derived from source/destination category:

- **P1** — Internet inbound (untrust → dmz → trust) · DNAT · IPS + AV + WildFire
- **P2** — User to internet (user-trust → user-untrust-egress) · SNAT · SSL decrypt + URL filter + DLP
- **P3** — User to service (user-trust → dc-trust) · no NAT · App-ID enforced · AD, DNS, NTP, PKI
- **P4** — Service to service (dc-trust ↔ dc-trust) · no NAT · named svc group · AD, NTP, Tanium, P2P
- **P5** — Machine to service (dc-trust → dc-trust) · no NAT · App-ID enforced · DB, MQ, internal API
- **P6** — Machine to internet (dc-trust → app-outbound) · SNAT · FQDN allowlist · conditional decrypt
- **P7** — IoT to service (iot-trust → dc-trust) · no NAT · strict allowlist · MQTT, SNMP, syslog
- **P8** — OT/IoT to internet · HARD BLOCK · mandatory security review
- **P9** — Partner/VPN (vpn-partner → dc-trust) · no NAT · strict IPS · no decrypt
- **P10** — NLB/ALB inbound (untrust → dmz/VIP → trust) · DNAT + SNAT-to-VIP · TWO RULES + TWO NAT POLICIES (atomic — must always generate both together)

Currently implemented in the tool: zone derivation from six-category model produces the pattern. Full P10 two-rule atomic output is not yet implemented.

---

## Object types (for Create Access Object)

When creating a new object, engineers declare the type — this drives the traffic pattern:
- **Server / Application** — standard server IPs → P5/P6 depending on zone pair
- **F5 Virtual IP** — F5 LTM VIP frontend → P10 (two rules + two NAT policies)
- **Cloud NLB / ALB** — AWS NLB, Azure LB, GCP TCP LB frontend → P10
- **SNAT Pool** — egress SNAT IP pool → P2/P6 egress patterns
- **FQDN / Service** — external service by hostname → P6 machine to internet

The single IP address model is critical: one IP can reference a real server, an F5 VIP, a cloud NLB/ALB, or a SNAT pool. The IP reverse lookup resolves to the named object, and the object type determines what rules get generated.

---

## Application intent model

The intent model defines a policy contract per application per environment. It is built into the tool but empty at launch — non-blocking, falls through silently.

Data structure:
```javascript
const INTENT = {
  "APP_CRBP_GCP": {
    "display_name": "Caremark Rx Benefits Platform",
    "owner": "CVS-APP-OWNERS-PBM",
    "environments": {
      "prod": { "approved_rules": [], "pending_rules": [] },
      "dev":  { "approved_rules": [], "pending_rules": [] }
    }
  }
}
```

When intent exists: tool shows badge "● Intent defined — N approved rules for prod" and can reference existing rules. When empty (all apps today): badge shows "○ No intent definition — standard request flow" and falls through to normal form.

Intent migration is a multi-year workstream. Do not block current functionality on it.

---

## Validation engine (for Create Access Group + Create Access Object)

External entries (public IPs, external FQDNs) must be validated before EDL generation. Internal entries (RFC1918, CVS-owned FQDNs resolving to RFC1918) pass through without checks.

**Processing order for each entry:**
1. Is it RFC1918? → Internal, no check
2. Is it an IP/CIDR? → ASN + GEO + reputation check
3. Is it an FQDN? → Strip port → DNS resolve → if resolves to RFC1918: internal, no check → if resolves to public IP: full recon on IP + domain intelligence
4. Is it a CVS-owned domain (cvshealth.com, aetna.com, caremark.com, cvs.com, etc.)? → Internal, no check
5. Unknown format? → ERROR, block EDL generation

**Risk levels and gating:**
- INTERNAL — pass, no check
- LOW — EDL generation enabled
- MEDIUM — EDL enabled with warning header comment
- ELEVATED / HIGH — EDL disabled, security review required
- ERROR — EDL disabled, fix entry first

**Currently:** Simulated recon using known ASN ranges (Google AS15169, AWS AS16509, Microsoft AS8075, Cloudflare AS13335, etc.). When Part 3 is built, replace `simDNS()` and `simRecon()` functions with live API calls — everything else stays the same.

**Edge cases handled:**
- FQDN with port (nexus-ha.cvshealth.com:9443) — strip port, validate FQDN, record port in metadata
- Internal FQDNs resolving to RFC1918 — substitute resolved IP in EDL output with comment
- External FQDNs — keep as FQDN in EDL output

---

## What has been built

### fw_rule_request.html (258KB standalone HTML)
Three-function tool — the main deliverable:

**Tab 1 — Create request:**
- Application object search (3,243 SO objects)
- Environment selector (Prod/Dev/QA/UAT/DR/Non-Prod)
- Intent definition hook (badge, falls through if empty)
- Rule type: Permit / Deny / Both (Deny/Both triggers auto-review flag)
- Source picker: six-category dropdown + free-text search + IP/hostname reverse lookup (/16 prefix map)
- Destination picker: same as source
- Traffic pattern auto-derivation (P1–P9) displayed as context bar
- Zone pills on selected objects (trust / vpn-partner / app-outbound)
- App-ID picker (77 App-IDs), IANA service picker (35 services), manual port entry
- Target device group: MID (Middletown CT), WIN (Windsor CT), PAZSHDC (Phoenix AZ SHEA), RRISHDC (Cumberland RI), ALL
- Generates: PAN-OS set commands, Cisco FMC REST API JSON, change ticket summary with reference ID

**Tab 2 — Create access group:**
- Category (Internal-Net/Partner-Net/External-Net), segment type, location, BU
- Live EDL name preview (NG-[SEGMENT]-[LOCATION]-[BU])
- Entry textarea (IPs, CIDRs, FQDNs — one per line)
- Validate entries button → validation panel with risk badges per entry
- Generate EDL button (disabled until validation passes)
- EDL output with validation status header comment

**Tab 3 — Create access object:**
- Object class (APP/SVC/DELIVERY/INFRA), type (Server/F5-VIP/NLB/SNAT/FQDN)
- App name + environment → live EDL name preview ([CLASS]_[APP]_[ENV])
- Entry textarea (IPs, CIDRs, FQDNs — supports paste from CSV files)
- Validate entries button → same validation engine as Tab 2
- Generate EDL button (disabled until validation passes)
- EDL output with resolved IP substitution for internal FQDNs

### fw_request_intake.html (117KB standalone HTML)
Metadata intake form for app teams (non-engineers):
- Application net object search
- Business unit (HCB / PSS / Retail)
- ITPR name/number (free text — future: ServiceNow lookup)
- Requester name (free text — future: AD lookup)
- AD group owner (free text — future: AD lookup)
- Justification category (PCI Requirement / Business Obligation / Business Continuity / Application Requirement / Monetary Compliance / CCSA)
- Free text justification
- VPN tunnel Y/N toggle
- 3rd party connection Y/N toggle
- Data classification (None / Confidential / Proprietary / Restricted / Public)
- Compliance requirements multi-select checkboxes: PHI / PII / PII(HICN) / PII(SSN) / SOC1 / SOC2 / SOX
- Request lifetime date picker (max today + 365 days)

### generate_app_names.py
Python script that calls Claude API in batches of 100 to generate human-readable names for all 3,237 SO objects. Produces app_name_map.json. Requires `pip install anthropic` and `ANTHROPIC_API_KEY`. Supports `--incremental` flag for catalog updates. Estimated runtime: under 2 minutes, cost ~$0.10–$0.30.

### Architecture document (FPMS_Technical_Architecture_v4.docx)
Version 2.0 — 839 paragraphs. Sections: executive summary, what has been built, CCD catalog integration, object model and intent, traffic pattern taxonomy, zone model, what still needs to be built, four-part architecture status, data catalog, build priorities, open items. Six appendices with architecture diagrams.

---

## Four-part architecture status

**Part 1 — Rule creation engine:** PARTIAL
Built: PAN-OS set commands, FMC JSON, change ticket, NAT rule generation
Not built: P10 two-rule atomic output, real security profile group names from Panorama, FMC domain UUID discovery

**Part 2 — Policy/rule request UI:** BUILT
Built: All three tabs, full catalog integration, validation engine, IP reverse lookup, pattern derivation

**Part 3 — Security context engine:** PLANNED
Built: Architecture designed, 10-pattern taxonomy, zone derivation logic in Part 1+2, simulated recon stubs
Not built: Live recon API calls (DNS, ASN/BGPView, GEO/MaxMind, reputation/VirusTotal/Talos, passive DNS/Farsight, cert transparency/crt.sh), risk scoring engine, automated zone assignment for external destinations

**Part 4 — Substrate:** PLANNED
Built: Intent data structure defined and hooked, reference IDs generated
Not built: Shared request state, lifecycle state machine (DRAFT→SUBMITTED→RECON_PENDING→ZONE_ASSIGNED→POLICY_REVIEW→RULE_GENERATED), audit trail, external resource catalog, approval workflow routing to ServiceNow

---

## What still needs to be built (in priority order)

1. **App name readable mapping** (2 hours)
   Run generate_app_names.py → produces app_name_map.json → embed in fw_rule_request.html
   Search picker shows "Caremark Rx Benefits Platform (GCP)" instead of "APP_CRBP_GCP"
   Requires: Anthropic API key from console.anthropic.com

2. **External-Net category reclassification** (30 min)
   NG-CLOUD, NG-AWS, NG-AZURE, NG-GCP currently misclassified as Internal-Net
   Fix: update category assignment in catalog parser — one-line code change

3. **P10 atomic two-rule generation** (3 hours)
   When destination type is F5-VIP or NLB/ALB → generate both rules atomically
   Rule 1: untrust → dmz/VIP (DNAT to VIP)
   Rule 2: dmz/VIP → trust (SNAT source to VIP)
   Must always generate both together — never partial P10 output

4. **Real security profile group names** (1 hour)
   Tool currently uses placeholder SPG names (e.g. "trust-spg", "app-outbound-spg")
   Need actual SPG names from Panorama (currently 98% use Alert-All-SPG)
   Replace placeholder derivation logic with real names per zone pair

5. **Catalog refresh automation** (1 week)
   Today: static embedded snapshot SO-20260617_v1 / NG-20260617_v1
   Need: scheduled export from CCD platform + re-embed process
   generate_app_names.py --incremental handles new objects only

6. **Live recon API integration — Part 3** (2–3 weeks)
   Replace simDNS() and simRecon() functions in fw_rule_request.html with live calls:
   - DNS resolution: standard DNS lookup
   - ASN/BGP: BGPView API (bgpview.io/api) or RIPEstat
   - GEO: MaxMind GeoIP database (local) or ip-api.com
   - Reputation: VirusTotal API, Cisco Talos, Palo Alto Autofocus/Unit 42
   - Passive DNS: Farsight DNSDB API
   - Certificate: crt.sh API (no key required)
   - Domain age: RDAP/WHOIS API
   Since the tool is a standalone HTML file, recon calls need a backend proxy
   or the tool needs a lightweight Python/Node server wrapper for the API calls

7. **Request routing to ServiceNow / email** (2–3 weeks)
   Today: form generates reference ID and summary but has no backend
   Need: submission POSTs to endpoint → creates ServiceNow ticket or email
   Engineer review queue: dashboard of pending requests
   Approval action: approve/modify/reject from queue
   On approval: rule output attached to change record

8. **Validated field lookups** (1–2 weeks each)
   ITPR/ticket → ServiceNow CMDB API
   Requester name → Active Directory LDAP
   AD group owner → Active Directory group catalog
   Application object → live CCD platform rather than embedded snapshot

9. **Substrate / shared state — Part 4** (3–4 weeks)
   Shared request state between intake form, recon, and rule generator
   Full lifecycle state machine
   Audit trail with reference IDs persisted
   External resource catalog (validated destinations with recon results)
   Platform translator registry (PAN-OS and FMC as pluggable modules)

10. **Intent definition editor** (multi-year workstream)
    Security architects define policy contracts per application per environment
    Backfill from existing rulebase
    New rules that extend intent go through approval before joining approved set
    Hook is already built — this is the data population and editor UI

---

## Open items / known issues

- **External-Net reclassification:** NG-CLOUD, NG-AWS, NG-AZURE, NG-GCP in Internal-Net category — one-line fix
- **Real SPG names:** Placeholder "zone-spg" names in rule output — need Panorama export
- **P10 not atomic:** F5-VIP and NLB types detected but only generate single rule currently
- **No backend routing:** Requests generate output but don't POST anywhere
- **AD/ServiceNow lookups:** ITPR and AD group owner are free text only
- **Anthropic API key:** Needed for generate_app_names.py — get from console.anthropic.com
- **Recon is simulated:** simDNS() and simRecon() must be replaced with live APIs for production
- **IPv6:** Not handled — flagged as "review manually" placeholder needed
- **CNAME chains:** simDNS follows one level only — production needs full chain following
- **CVS Health AS numbers:** Hardcoded as AS64496 in simulation — need real CVS/Aetna ASN list
- **Panorama device-group syntax:** Verify set command syntax per Panorama version
- **AD domain controller groups:** AG_AD-* dynamic groups (300+ DCs) not yet in object picker

---

## Key design decisions made

- **Zone is always derived, never selected** — source/dest category → zone pair → pattern → NAT + SPG + decrypt
- **Intent is non-blocking** — empty at launch, activates per-app as populated
- **Validation gates EDL generation** — Generate button disabled until Validate runs and passes
- **RFC1918 always internal** — no recon on private IP space regardless of object type
- **FQDN resolution is mandatory** — must resolve before classification, unresolvable = ERROR = blocked
- **Internal FQDNs substituted with resolved IPs in EDL** — external FQDNs kept as FQDNs
- **P10 is atomic** — F5 VIP and NLB object types must always produce two rules + two NAT policies together
- **Deny/Both triggers auto-review** — cannot self-approve deny rules
- **Request lifetime max 1 year** — enforced on date picker
- **No backend required for core function** — tool generates paste-ready output, engineers copy/paste to Panorama or FMC
- **Catalog version tagged in topbar** — SO-20260617_v1 / NG-20260617_v1 visible to engineers

---

## File inventory

All delivered files:
- `fw_rule_request.html` — 258KB — main three-function tool (Create Request, Create Access Group, Create Access Object)
- `fw_request_intake.html` — 117KB — metadata intake form for app teams
- `generate_app_names.py` — Python script for generating readable app names via Claude API
- `FPMS_Technical_Architecture_v4.docx` — Version 2.0 architecture document with status tracking

---

## Use case example (jenk-git.csv)

The Jenkins/CI-CD infrastructure file was provided as a use case for Create Access Object:
- Jenkins instances: jenkins-digital.cvshealth.com, jenkins-sprx-01.cvshealth.com, jenkins-pbm-01.cvshealth.com, jenkins-retail-01.cvshealth.com, jenkins.cvshealth.com
- Nexus repos: nexus-ha.cvshealth.com:9443, nexus-az.cvshealth.com:9443, cicd-nexusenterprise.cvshealth.com:8443
- Azure Octopus subnets: 10.242.66.128/26, 10.242.66.192/27
- Jenkins IPs: 10.249.16.18, 10.249.8.0/22
- Git runners: 10.83.217.128/26, 10.83.223.128/26, 10.83.141.128/26, 10.83.141.64/26, etc.

Expected validation outcome: all CVS domain FQDNs resolve to RFC1918 → INTERNAL. All 10.x IPs → INTERNAL. Object name would be SVC_CICD_CVS. EDL output substitutes resolved RFC1918 IPs for the FQDNs.

---

## Technical environment

- Palo Alto Networks Panorama — four stacks: MID (Middletown CT), WIN (Windsor CT), PAZSHDC (Phoenix AZ SHEA DC), RRISHDC (Cumberland RI 2100 Highland)
- Cisco FMC — REST API v1 integration
- CCD platform — builds EDL files via build_service_objects.py and build_network_groups.py
- CVS Health domains: cvshealth.com, aetna.com, caremark.com, cvs.com, cvscaremark.com, minuteclinic.com, omnicare.com, careplus.com
- AD domains referenced in catalog: ad-aetna, ad-corp-cvs, ad-corp-cvscaremark, ad-caremarkrx, ad-pdcss, ad-pdchs, ad-omnicare, ad-minclinic, ad-meritain, ad-ahm, ad-cvty, and many more

---

## App-ID data source (decided end of session)

**Current state:** 77 manually curated App-IDs hardcoded in the HTML as the `AIDS` array. This is a placeholder.

**Correct source:** Palo Alto Applipedia — the official App-ID catalog.

**Recommended approach — pull from Panorama XML API:**
This gives standard App-IDs PLUS any custom App-ID signatures defined for internal CVS/Aetna applications.

PAN-OS XML API call:
```
GET https://<panorama>/api/?type=op&cmd=<show><object><application><all></all></application></object></show>&key=<apikey>
```

Returns all App-IDs the device knows — standard library + custom. Run against all four stacks (MID, WIN, PAZSHDC, RRISHDC) and merge, deduplicating by app name.

**Output format needed for the tool:**
```javascript
const AIDS = ["ssl","kerberos","ldap","oracle","ms-teams",...]; // simple name array
```

Or richer if we want descriptions in the picker:
```javascript
const AIDS = [
  { name: "ssl", category: "networking", risk: "4", description: "SSL/TLS encrypted traffic" },
  ...
];
```

**Alternative sources:**
- Applipedia website: applipedia.paloaltonetworks.com (public, community JSON exports on GitHub)
- PAN-OS XML API app export — same as above but filtered to your estate

**Action item for next session:**
1. Pull App-ID list from Panorama XML API (or use Applipedia export)
2. Include custom App-ID signatures from CVS/Aetna Panoramas
3. Replace the `AIDS` array in fw_rule_request.html with full dataset
4. Update App-ID picker UI to show category, risk level, and description alongside the name
